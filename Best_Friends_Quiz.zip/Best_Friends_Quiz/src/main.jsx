import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import {
  ArrowLeft, ArrowRight, Check, ChevronRight, Copy, Crown, Gamepad2,
  Link2, Medal, Plus, Share2, Sparkles, Trophy, Users, Zap
} from 'lucide-react';
import './style.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const BANK = [
  { q: '¿Cuál es mi comida favorita?', options: ['Pizza', 'Hamburguesa', 'Pollo', 'Pasta'] },
  { q: '¿Cuál es mi color favorito?', options: ['Negro', 'Azul', 'Morado', 'Rojo'] },
  { q: '¿Qué música escucho más?', options: ['Trap', 'Dembow', 'Phonk', 'Reguetón'] },
  { q: '¿Cuál es mi videojuego favorito?', options: ['Free Fire', 'Minecraft', 'Car Parking Multiplayer', 'FIFA'] },
  { q: '¿Qué prefiero hacer en mi tiempo libre?', options: ['Jugar', 'Dormir', 'Escuchar música', 'Salir'] },
  { q: '¿Cuál es uno de mis mayores sueños?', options: ['Viajar', 'Ser famoso', 'Tener mi negocio', 'Tener una profesión'] },
  { q: '¿Qué me hace reír más?', options: ['Memes', 'Bromas', 'Videos', 'Mis amigos'] },
  { q: '¿Qué prefiero para pasar el día?', options: ['Playa', 'Montaña', 'Ciudad', 'Casa'] },
  { q: '¿Qué deporte me gusta más?', options: ['Baloncesto', 'Fútbol', 'Béisbol', 'Voleibol'] },
  { q: '¿Cómo soy normalmente?', options: ['Tranquilo', 'Gracioso', 'Serio', 'Hablador'] },
  { q: '¿Qué valoro más en una amistad?', options: ['Confianza', 'Diversión', 'Lealtad', 'Apoyo'] },
  { q: '¿Qué elegiría para un día libre?', options: ['Jugar', 'Ver películas', 'Salir', 'Escuchar música'] },
  { q: '¿Qué prefiero comer?', options: ['Dulce', 'Salado', 'Ambos', 'Depende del día'] },
  { q: '¿Qué plan me gusta más con amigos?', options: ['Jugar', 'Comer juntos', 'Ir de paseo', 'Hablar'] },
  { q: '¿Qué recuerdo me gusta más?', options: ['Las salidas', 'Las bromas', 'Las conversaciones', 'Las aventuras'] }
];

const makeId = () => Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 5);
const shareUrl = (id) => `${window.location.origin}${window.location.pathname}?reto=${encodeURIComponent(id)}`;
const titleFor = (score) => score === 100 ? 'LEYENDA DE LA AMISTAD' : score >= 80 ? 'AMIGO DE CONFIANZA' : score >= 60 ? 'AMIGO EN ENTRENAMIENTO' : score >= 35 ? 'CASI NOS CONOCEMOS' : 'DESCONOCIDO TOTAL';
const messageFor = (score) => score === 100 ? '¡Conoces cada detalle!' : score >= 80 ? '¡Esa amistad va en serio!' : score >= 60 ? 'Vas por buen camino.' : score >= 35 ? 'Hay cosas por descubrir.' : '¡Toca pasar más tiempo juntos!';

function App() {
  const [screen, setScreen] = useState('home');
  const [owner, setOwner] = useState('');
  const [player, setPlayer] = useState('');
  const [questions, setQuestions] = useState([]);
  const [answerKey, setAnswerKey] = useState({});
  const [quizId, setQuizId] = useState('');
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [index, setIndex] = useState(0);
  const [result, setResult] = useState(null);
  const [ranking, setRanking] = useState([]);
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);

  const isSharedQuiz = new URLSearchParams(window.location.search).has('reto');
  const currentQuestion = questions[index];

  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get('reto');
    if (id) loadQuiz(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadQuiz(id) {
    setLoading(true);
    setNotice('');
    try {
      let found = null;
      if (supabase) {
        const { data, error } = await supabase.from('quizzes').select('id, owner_name, questions, created_at').eq('id', id).maybeSingle();
        if (error) throw error;
        found = data;
      } else {
        const saved = JSON.parse(localStorage.getItem(`bfq_quiz_${id}`) || 'null');
        found = saved;
      }
      if (!found) {
        setNotice('No encontramos este reto. Pídele a tu amigo que cree y comparta un enlace nuevo.');
        setScreen('home');
      } else {
        setQuiz(found);
        setQuizId(found.id);
        setOwner(found.owner_name);
        setQuestions(found.questions);
        setAnswers({});
        setIndex(0);
        setScreen('answer');
      }
    } catch (e) {
      setNotice('No se pudo cargar el reto. Revisa la configuración de Supabase e inténtalo de nuevo.');
      setScreen('home');
    } finally {
      setLoading(false);
    }
  }

  function beginCreate() {
    setOwner('');
    setQuestions(BANK.map((item, i) => ({ ...item, id: `q${i + 1}` })));
    setAnswerKey({});
    setScreen('create');
    setNotice('');
  }

  function setCorrect(qid, option) {
    setAnswerKey(prev => ({ ...prev, [qid]: option }));
  }

  async function createQuiz() {
    if (!owner.trim()) return setNotice('Escribe tu nombre para crear el reto.');
    if (questions.some(q => answerKey[q.id] === undefined)) return setNotice('Marca una respuesta correcta en cada pregunta.');
    setLoading(true);
    setNotice('');
    const id = makeId();
    const publicQuestions = questions.map(q => ({ id: q.id, q: q.q, options: q.options }));
    try {
      if (supabase) {
        const { error } = await supabase.from('quizzes').insert({
          id, owner_name: owner.trim(), questions: publicQuestions, answer_key: answerKey
        });
        if (error) throw error;
      } else {
        // Demo local: sirve en este navegador; para compartir entre dispositivos configura Supabase.
        localStorage.setItem(`bfq_quiz_${id}`, JSON.stringify({
          id, owner_name: owner.trim(), questions: publicQuestions, answer_key: answerKey, created_at: new Date().toISOString()
        }));
        localStorage.setItem(`bfq_key_${id}`, JSON.stringify(answerKey));
      }
      setQuizId(id);
      setQuiz({ id, owner_name: owner.trim(), questions: publicQuestions });
      setQuestions(publicQuestions);
      setScreen('created');
    } catch (e) {
      setNotice('No se pudo guardar el reto. Revisa la configuración de Supabase.');
    } finally {
      setLoading(false);
    }
  }

  async function finishQuiz() {
    if (!player.trim()) return setNotice('Escribe tu nombre antes de enviar las respuestas.');
    const key = await getAnswerKey(quizId);
    if (!key) return setNotice('No se pudo comprobar el reto. Vuelve a abrir el enlace.');
    const correct = questions.reduce((sum, q) => sum + (Number(answers[q.id]) === Number(key[q.id]) ? 1 : 0), 0);
    const score = Math.round(correct / questions.length * 100);
    const attempt = { id: makeId(), player_name: player.trim(), score, correct_count: correct, total: questions.length, created_at: new Date().toISOString() };
    setResult(attempt);
    try {
      if (supabase) {
        const { error } = await supabase.from('attempts').insert({ quiz_id: quizId, ...attempt });
        if (error) throw error;
      } else {
        const all = JSON.parse(localStorage.getItem(`bfq_attempts_${quizId}`) || '[]');
        all.push(attempt);
        localStorage.setItem(`bfq_attempts_${quizId}`, JSON.stringify(all));
      }
    } catch {
      setNotice('Resultado calculado, pero no se pudo guardar en el ranking.');
    }
    setScreen('result');
  }

  async function getAnswerKey(id) {
    try {
      if (supabase) {
        const { data, error } = await supabase.from('quizzes').select('answer_key').eq('id', id).maybeSingle();
        if (error) throw error;
        return data?.answer_key || null;
      }
      return JSON.parse(localStorage.getItem(`bfq_key_${id}`) || localStorage.getItem(`bfq_quiz_${id}`) || 'null')?.answer_key || null;
    } catch { return null; }
  }

  async function showRanking() {
    setLoading(true);
    setNotice('');
    try {
      let rows = [];
      if (supabase) {
        const { data, error } = await supabase.from('attempts').select('player_name, score, correct_count, created_at').eq('quiz_id', quizId).order('score', { ascending: false }).order('created_at', { ascending: true }).limit(100);
        if (error) throw error;
        rows = data || [];
      } else {
        rows = JSON.parse(localStorage.getItem(`bfq_attempts_${quizId}`) || '[]');
        rows.sort((a, b) => b.score - a.score || new Date(a.created_at) - new Date(b.created_at));
      }
      setRanking(rows);
      setScreen('ranking');
    } catch {
      setNotice('No se pudo cargar el ranking.');
    } finally { setLoading(false); }
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(shareUrl(quizId));
      setNotice('¡Enlace copiado! Ya puedes enviarlo a tus amigos.');
    } catch {
      setNotice(shareUrl(quizId));
    }
  }

  async function shareLink() {
    const url = shareUrl(quizId);
    if (navigator.share) {
      try { await navigator.share({ title: 'Best Friends Quiz', text: `¿Cuánto me conoces? Responde mi reto de ${owner}.`, url }); }
      catch { /* El usuario puede cerrar el menú de compartir. */ }
    } else copyLink();
  }

  function resetHome() {
    setScreen('home');
    setNotice('');
    setResult(null);
    setPlayer('');
    setQuiz(null);
    setQuizId('');
    window.history.replaceState({}, '', window.location.pathname);
  }

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={resetHome} aria-label="Ir al inicio">
        <span className="brand-mark"><Gamepad2 size={23}/></span>
        <span>BEST FRIENDS <b>QUIZ</b></span>
      </button>
      <span className="online-pill"><i/> RETO DE AMISTAD</span>
    </header>

    <main className="main">
      {notice && <div className="notice" role="status">{notice}</div>}
      {loading && <div className="loading"><span className="spinner"/> Cargando...</div>}

      {screen === 'home' && <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={15}/> EL RETO DEFINITIVO DE AMISTAD</div>
          <h1>¿QUIÉN TE<br/><span>CONOCE</span> DE VERDAD?</h1>
          <p>Crea tu test, comparte el enlace y descubre cuál de tus amigos conoce más sobre ti.</p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={beginCreate}><Zap size={18}/> Crear mi test <ArrowRight size={17}/></button>
            <button className="btn btn-secondary" onClick={() => {
              const id = prompt('Pega el código o enlace del reto:');
              if (id) {
                const match = id.match(/[?&]reto=([^&]+)/);
                loadQuiz(decodeURIComponent(match ? match[1] : id.trim()));
              }
            }}><Link2 size={17}/> Responder un reto</button>
          </div>
          <div className="mini-stats">
            <div><strong>15</strong><span>preguntas</span></div><div><strong>100%</strong><span>diversión</span></div><div><strong>∞</strong><span>retos</span></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
          <div className="floating-card card-top"><Crown size={19}/><span>MEJOR AMIGO</span><b>+100 XP</b></div>
          <div className="neon-controller"><Gamepad2 size={104} strokeWidth={1.35}/><span className="controller-spark">✦</span></div>
          <div className="floating-card card-bottom"><div className="avatar-stack"><span>A</span><span>M</span><span>J</span></div><div><b>Tu grupo</b><small>¿Quién te conoce más?</small></div><Trophy className="trophy-icon" size={24}/></div>
        </div>
        <div className="feature-strip">
          <div><span className="feature-icon purple"><Users size={19}/></span><b>Retos con amigos</b><small>Comparte con un enlace</small></div>
          <div><span className="feature-icon cyan"><Trophy size={19}/></span><b>Ranking</b><small>Compite por el primer lugar</small></div>
          <div><span className="feature-icon pink"><Sparkles size={19}/></span><b>Resultados</b><small>Descubre tu porcentaje</small></div>
        </div>
      </section>}

      {screen === 'create' && <section className="panel">
        <button className="back-link" onClick={resetHome}><ArrowLeft size={16}/> Inicio</button>
        <div className="section-heading"><span className="eyebrow">PASO 1 DE 2</span><h2>Crea tu reto <span>💜</span></h2><p>Marca la respuesta que mejor te representa en cada pregunta. Tus amigos intentarán adivinarla.</p></div>
        <label className="field-label">Tu nombre o apodo</label>
        <input className="text-input" maxLength={30} value={owner} onChange={e => setOwner(e.target.value)} placeholder="Ej. Alex" />
        <div className="question-list">
          {questions.map((q, i) => <div className="setup-question" key={q.id}>
            <div className="question-number">{String(i + 1).padStart(2, '0')}</div>
            <div className="setup-content"><h3>{q.q}</h3><div className="option-grid">
              {q.options.map((op, oi) => <button key={op} className={`option-chip ${answerKey[q.id] === oi ? 'selected' : ''}`} onClick={() => setCorrect(q.id, oi)}><span>{String.fromCharCode(65 + oi)}</span>{op}{answerKey[q.id] === oi && <Check size={15}/>}</button>)}
            </div></div>
          </div>)}
        </div>
        <button className="btn btn-primary full" disabled={loading} onClick={createQuiz}><Sparkles size={18}/> {loading ? 'Creando...' : 'Crear mi enlace de reto'} <ArrowRight size={17}/></button>
      </section>}

      {screen === 'created' && <section className="panel center-panel">
        <div className="success-orb"><Check size={36}/></div><span className="eyebrow">RETO CREADO</span><h2>¡Todo listo, {owner}!</h2><p>Comparte este enlace para ver quién te conoce mejor.</p>
        <div className="share-box"><span>{shareUrl(quizId)}</span><button className="icon-btn" onClick={copyLink} aria-label="Copiar enlace"><Copy size={18}/></button></div>
        <div className="stack-buttons"><button className="btn btn-primary full" onClick={shareLink}><Share2 size={18}/> Compartir reto</button><button className="btn btn-secondary full" onClick={showRanking}><Trophy size={18}/> Ver ranking</button><button className="text-btn" onClick={resetHome}>Volver al inicio</button></div>
        {!supabase && <p className="warning-text">Modo demostración local: para que el enlace funcione en otros teléfonos, conecta Supabase siguiendo README.md.</p>}
      </section>}

      {screen === 'answer' && currentQuestion && <section className="panel quiz-panel">
        <div className="quiz-top"><span className="eyebrow">RETO DE {owner.toUpperCase()}</span><span className="question-count">{index + 1} / {questions.length}</span></div>
        <div className="progress-track"><div style={{width: `${((index + 1) / questions.length) * 100}%`}}/></div>
        <div className="quiz-question"><span className="question-kicker">PREGUNTA {String(index + 1).padStart(2, '0')}</span><h2>{currentQuestion.q}</h2><p>¿Qué respuesta elegiría {owner}?</p></div>
        <div className="answer-options">{currentQuestion.options.map((op, oi) => <button key={op} className={`answer-option ${answers[currentQuestion.id] === oi ? 'picked' : ''}`} onClick={() => setAnswers(prev => ({...prev, [currentQuestion.id]: oi}))}><span>{String.fromCharCode(65 + oi)}</span>{op}{answers[currentQuestion.id] === oi && <Check size={18}/>}</button>)}</div>
        <div className="quiz-footer"><button className="btn btn-secondary" disabled={index === 0} onClick={() => setIndex(i => i - 1)}><ArrowLeft size={16}/> Anterior</button>{index < questions.length - 1 ? <button className="btn btn-primary" disabled={answers[currentQuestion.id] === undefined} onClick={() => setIndex(i => i + 1)}>Siguiente <ArrowRight size={16}/></button> : <button className="btn btn-primary" disabled={Object.keys(answers).length !== questions.length} onClick={() => setScreen('submit')}><Check size={17}/> Terminar test</button>}</div>
      </section>}

      {screen === 'submit' && <section className="panel center-panel">
        <div className="success-orb"><Trophy size={34}/></div><h2>¡Último paso!</h2><p>Escribe tu nombre para guardar tu resultado en el ranking del reto de {owner}.</p>
        <label className="field-label align-left">Tu nombre o apodo</label><input className="text-input" maxLength={30} value={player} onChange={e => setPlayer(e.target.value)} placeholder="Ej. Dani"/>
        <button className="btn btn-primary full" onClick={finishQuiz}>Ver mi puntuación <ArrowRight size={17}/></button>
        <button className="text-btn" onClick={() => setScreen('answer')}>Volver a las preguntas</button>
      </section>}

      {screen === 'result' && result && <section className="panel center-panel">
        <div className="result-medal"><Trophy size={39}/></div><span className="eyebrow">RESULTADO DE {player.toUpperCase()}</span>
        <div className="score-number">{result.score}<small>%</small></div><h2>{titleFor(result.score)}</h2><p>{messageFor(result.score)}</p>
        <div className="score-detail"><div><strong>{result.correct_count}/{result.total}</strong><span>Respuestas acertadas</span></div><div><strong>{result.total - result.correct_count}</strong><span>Por descubrir</span></div></div>
        <div className="stack-buttons"><button className="btn btn-primary full" onClick={showRanking}><Trophy size={18}/> Ver ranking del reto</button><button className="btn btn-secondary full" onClick={shareLink}><Share2 size={18}/> Compartir reto</button><button className="text-btn" onClick={resetHome}>Volver al inicio</button></div>
      </section>}

      {screen === 'ranking' && <section className="panel">
        <button className="back-link" onClick={() => setScreen(quiz ? 'created' : 'result')}><ArrowLeft size={16}/> Volver</button>
        <div className="section-heading"><span className="eyebrow">CLASIFICACIÓN DEL RETO</span><h2>Ranking <span>🏆</span></h2><p>Estos son los amigos que más respuestas acertaron.</p></div>
        {ranking.length === 0 ? <div className="empty-state"><Trophy size={38}/><h3>Aún no hay puntuaciones</h3><p>Comparte el enlace para que tus amigos jueguen y aparezcan aquí.</p></div> : <div className="ranking-list">{ranking.map((r, i) => <div className={`rank-row ${i < 3 ? 'top-rank' : ''}`} key={`${r.player_name}-${r.created_at}-${i}`}><div className={`rank-place rank-${i + 1}`}>{i === 0 ? <Crown size={18}/> : i === 1 ? <Medal size={18}/> : i === 2 ? <Medal size={18}/> : i + 1}</div><div className="rank-avatar">{(r.player_name || '?').slice(0, 1).toUpperCase()}</div><div className="rank-name"><b>{r.player_name}</b><small>{r.correct_count} respuestas correctas</small></div><strong className="rank-score">{r.score}%</strong></div>)}</div>}
        <button className="btn btn-primary full" onClick={shareLink}><Share2 size={17}/> Invitar a más amigos</button>
      </section>}
    </main>
    <footer><span className="footer-brand"><Gamepad2 size={17}/> BEST FRIENDS QUIZ</span><span>Hecho para poner a prueba la amistad 💜</span></footer>
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
