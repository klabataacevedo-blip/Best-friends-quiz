-- Ejecuta este SQL en Supabase > SQL Editor.
-- Nota: el ranking se mantiene público para los retos compartidos.
-- Para un lanzamiento público, revisa límites anti-spam y políticas según tu caso de uso.

create extension if not exists pgcrypto;

create table if not exists public.quizzes (
  id text primary key,
  owner_name text not null check (char_length(owner_name) between 1 and 30),
  questions jsonb not null,
  answer_key jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.attempts (
  id text primary key,
  quiz_id text not null references public.quizzes(id) on delete cascade,
  player_name text not null check (char_length(player_name) between 1 and 30),
  score integer not null check (score between 0 and 100),
  correct_count integer not null check (correct_count >= 0),
  total integer not null check (total > 0),
  created_at timestamptz not null default now()
);

alter table public.quizzes enable row level security;
alter table public.attempts enable row level security;

-- La clave correcta NO se consulta desde el cliente mediante select.
-- En producción, lo recomendable es mover la verificación a una Edge Function.
-- Estas políticas permiten demo sencilla, pero no ocultan answer_key de forma segura
-- si la tabla completa queda expuesta. Ver README para la recomendación de producción.

drop policy if exists "quizzes public read" on public.quizzes;
create policy "quizzes public read" on public.quizzes for select using (true);

drop policy if exists "quizzes public create" on public.quizzes;
create policy "quizzes public create" on public.quizzes for insert with check (true);

drop policy if exists "attempts public read" on public.attempts;
create policy "attempts public read" on public.attempts for select using (true);

drop policy if exists "attempts public create" on public.attempts;
create policy "attempts public create" on public.attempts for insert with check (true);

-- IMPORTANTE:
-- Este SQL es una configuración inicial de prototipo, no una configuración endurecida
-- para una web pública. La app debe mover answer_key a una tabla privada o Edge Function
-- antes de lanzarse públicamente. Nunca pongas la service_role key en el frontend.
