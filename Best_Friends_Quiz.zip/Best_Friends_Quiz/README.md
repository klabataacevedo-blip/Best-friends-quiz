# Best Friends Quiz 💜

Web responsive en React + Vite con estética gaming neón. Incluye:
- Pantalla de inicio
- Creador de reto con 15 preguntas y respuesta elegida por el creador
- Cuestionario de amigos
- Cálculo de porcentaje y resultado
- Compartir enlace
- Ranking de intentos

## 1. Probar en tu computadora

Necesitas Node.js instalado.

```bash
npm install
npm run dev
```

Vite mostrará una dirección local para abrir la web. Para crear la versión de producción:

```bash
npm run build
```

## 2. Modo demo

Sin Supabase, el proyecto permite crear y responder retos en el mismo navegador usando localStorage. **Los enlaces no se sincronizan entre distintos teléfonos** en este modo.

## 3. Conectar Supabase para compartir entre dispositivos

1. Crea un proyecto en https://supabase.com/.
2. Entra en SQL Editor y ejecuta `supabase.sql`.
3. Copia `.env.example` como `.env`.
4. En el panel del proyecto, busca Project URL y la clave publicable (anon/publishable).
5. Rellena:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. Reinicia `npm run dev`.

## 4. Seguridad antes de publicar

Este repositorio es un prototipo educativo. En la versión actual, la app consulta `answer_key` desde el cliente. No lo publiques así con datos reales: alguien con conocimientos técnicos podría inspeccionar las respuestas correctas.

Para producción:
- Guarda `answer_key` en una tabla privada que no tenga acceso público.
- Implementa una Supabase Edge Function que valide las respuestas y calcule la puntuación en el servidor.
- Deja que el navegador reciba solo preguntas y opciones públicas.
- Añade límites de solicitudes y protección contra spam.
- Configura políticas RLS estrictas. No uses la `service_role` key en el frontend.
- Considera que nombres y resultados son datos personales: ofrece aviso de privacidad y una forma de eliminar los datos.

## 5. Publicar gratis

1. Sube el proyecto a un repositorio Git.
2. Importa el repositorio en https://vercel.com/.
3. Añade las variables de entorno de Supabase en los ajustes del proyecto de Vercel.
4. Publica. Comparte el dominio que te proporcione Vercel.

## Estructura

- `src/main.jsx` — lógica y pantallas
- `src/style.css` — diseño responsive neón
- `supabase.sql` — esquema de base de datos de prototipo
- `.env.example` — variables de configuración
